export type JwtPayload = {
  name: string;
  studentId: string;
  phoneNumber: string;
};
